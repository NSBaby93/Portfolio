<div id="sidebar-left" class="span2">
    <div class="nav-collapse sidebar-nav">
        <ul class="nav nav-tabs nav-stacked main-menu">
            <li><a href="admin_master.php"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a></li>
            <li><a href="home.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Manage Home Content</span></a></li>
            <li><a href="about.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Manage About Page</span></a></li>
            <li><a href="portfolio.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Manage Portfolio Info</span></a></li>
            <li><a href="gallery.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Gallery</span></a></li>
            <li><a href="contact.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Contact</span></a></li>
         
        </ul>
    </div>
</div>