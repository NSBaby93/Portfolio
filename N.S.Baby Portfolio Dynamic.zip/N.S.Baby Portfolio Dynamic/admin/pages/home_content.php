<?php
if(isset($_POST['btn'])){
    $message = $ob_sup_admin->save_vision_info($_POST);
}
?>

<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Your Home Info Form</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
<h2 style="color: green;"><?php if(isset($message)) {echo $message;} ?></h2>
        <div class="box-content">
            <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label" for="typeahead">Vision First Paragraph </label>
                        <div class="controls">
                            <textarea class="cleditor" name="vision_first" rows='8'></textarea> 
                        </div>
                    </div>



                    <div class="control-group">
                        <label class="control-label" for="typeahead">Your Vision Side Image </label>
                        <div class="controls">
                            <input type="file" name="vision_image" value="Change Image" class="span6 typeahead" id="typeahead"> 
                        </div>

                        <div class="controls">
                            <img src="" width="300px">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="typeahead">Vision Last Paragraph </label>
                        <div class="controls">
                            <textarea class="cleditor" name="vision_last" rows='8'></textarea> 
                        </div>

                    </div>

                    <div class="form-actions">
                        <button type="submit" name="btn" class="btn btn-primary">Update Vision</button>
                        <button type="reset" class="btn">Reset</button>
                    </div>
                </fieldset>
            </form>   
        </div>
    </div><!--/span-->
</div><!--/row-->

<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Your Dreams</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        <div class="box-content">
            <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label" for="typeahead">Add Your Dreams</label>
                        <div class="controls">
                            <textarea class="cleditor" name="dream_details" rows='8'></textarea> 
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="btn_dream" class="btn btn-primary">Add Dream</button>
                        <button type="reset" class="btn">Reset</button>
                    </div>
                </fieldset>
            </form>   
        </div>
    </div><!--/span-->
</div>


<div class="row-fluid sortable">		
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon user"></i><span class="break"></span>Manage Your Dreams</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        <div class="box-content">

            <table class="table table-striped table-bordered bootstrap-datatable datatable">
                <thead>
                    <tr>
                        <th>Dream ID</th>
                        <th>Your Dreams</th>
                        <th>Publication Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>   
                <tbody>

                    <tr>
                        <td></td>

                        <td class="center"></td>
                        <td class="center">
                            <a class="btn btn-success" href="" title="">
                                <i class="halflings-icon white arrow-down"></i>  
                            </a>

                            <a class="btn btn-danger" href="" title="">
                                <i class="halflings-icon white arrow-up"></i>  
                            </a>

                        </td>

                        <td class="center">


                            <a class="btn btn-danger" href="" title="t" onclick="return">
                                <i class="halflings-icon white trash"></i> 
                            </a>
                        </td>
                    </tr>

                </tbody>
            </table>            
        </div>
    </div><!--/span-->

</div>

