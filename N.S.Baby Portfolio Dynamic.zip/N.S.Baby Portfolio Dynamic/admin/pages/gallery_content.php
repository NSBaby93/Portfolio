
<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Upload Image Form</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        
        <div class="box-content">
            <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label" for="typeahead">Select Image </label>
                        <div class="controls">
                            <input type="file" name="gallery_image" value="Change Image" class="span6 typeahead" id="typeahead"> 
                        </div>
                    </div>
                    

                    <div class="form-actions">
                        <button type="submit" name="btn" class="btn btn-primary">Upload Image</button>
                        <button type="reset" class="btn">Reset</button>
                    </div>
                </fieldset>
            </form>   
        </div>
    </div><!--/span-->
</div><!--/row-->



<div class="row-fluid sortable">		
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon user"></i><span class="break"></span>Manage Your Images</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        <div class="box-content">

            <table class="table table-striped table-bordered bootstrap-datatable datatable">
                <thead>
                    <tr>
                        <th>Gallery ID</th>
                        
                        <th>Image</th>
                        <th>Publication Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>   
                <tbody>
                    
                        <tr>
                            <td></td>
                            
                            <td class="center"><img src="" width="120px"></td>
                            <td class="center">
                                    <a class="btn btn-success" href="?status=unpublished&&id=" title="Unpublish it">
                                        <i class="halflings-icon white arrow-down"></i>  
                                    </a>
                                    
                                    <a class="btn btn-danger" href="?status=published&&id=" title="Publish it">
                                        <i class="halflings-icon white arrow-up"></i>  
                                    </a>
                                    
                            </td>

                            <td class="center">


                                <a class="btn btn-danger" href="?status=delete&&id=" title="Delete it" onclick="return ">
                                    <i class="halflings-icon white trash"></i> 
                                </a>
                            </td>
                        </tr>
                    
                </tbody>
            </table>            
        </div>
    </div><!--/span-->

</div>
