<?php

$pages = 'home';
include './admin_master.php';

