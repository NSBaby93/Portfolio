<?php

$pages = 'contact';
include './admin_master.php';

