<?php

$pages = 'portfolio';
include './admin_master.php';

