<?php

$pages = 'about';
include './admin_master.php';

