<?php

$pages = 'gallery';
include './admin_master.php';

