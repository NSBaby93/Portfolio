<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>N.S.BABY | Portfolio</title>
        <link rel="stylesheet" href="assets/front_end_assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/front_end_assets/fonts/lavanderia-regular-font-styles.css" />
	<link rel="stylesheet" href="assets/front_end_assets/css/style.css">
</head>
<body>

	<div class="main_div">

<!-- =================Header Area Starts Here=================== -->
		<?php include './includes/header.php';?>
	
<!-- =================Header Area ends Here=================== -->

<!-- =================Content Area Starts Here=================== -->
		<?php
                    if(isset($pages)){
                        if ($pages == 'about') {
                            include './pages/about_content.php';
                        } else if ($pages == 'portfolio') {
                            include './pages/portfolio_content.php';
                        } else if ($pages == 'gallery') {
                            include './pages/gallery_content.php';
                        } else if ($pages == 'contact') {
                            include './pages/contact_content.php';
                        }
                    } else{
                        include './pages/home_content.php';
                    }
                
                
                
                ?>

<!-- =================Content Area ends Here=================== -->

<!-- =================Footer Area starts Here=================== -->
	<?php include './includes/footer.php';?>
<!-- ====================Footer Area ends Here=================== -->
	</div>
	
</body>
</html>
