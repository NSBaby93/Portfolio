<?php
$pages = 'portfolio';
include './index.php';
