<?php
$pages = 'gallery';
include './index.php';
