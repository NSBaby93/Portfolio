<footer class="footer_area">
    <p>Designed and Developed by  <a href="index.php">Nasrin Sultana Baby </a> || &copy; 2017</p>
</footer>