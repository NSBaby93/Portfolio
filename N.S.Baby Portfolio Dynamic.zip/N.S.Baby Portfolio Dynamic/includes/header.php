<header class="header_area">
    <div class="logo_area">
        <a href="index.php"><img src="assets/front_end_assets/images/logo.jpg" alt="Logo Image" /></a>
    </div>
    <div class="menu_area">
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="portfolio.php">Portfolio</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </div>
</header>