<?php

class Application {

    private $db_connect;

    public function __construct() {
        $host_name = 'localhost';
        $user_name = 'root';
        $password = '';
        $db_name = 'db_portfolio';
        $this->db_connect = mysqli_connect($host_name, $user_name, $password, $db_name);
        if (!$this->db_connect) {
            die('Connection Fail' . mysqli_error($this->db_connect));
        }
    }
    
    
    
    public function select_vision_info_by_id(){
      $sql="SELECT * From tbl_vision WHERE vision_id=1";
        if (mysqli_query($this->db_connect, $sql)){
        $query_result = mysqli_query($this->db_connect, $sql);
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($this->db_connect));
        }  
    }
    
    
    public function select_about_info_by_id(){
      $sql="SELECT * From tbl_about WHERE about_id=1";
        if (mysqli_query($this->db_connect, $sql)){
        $query_result = mysqli_query($this->db_connect, $sql);
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($this->db_connect));
        }  
    }
    
    
    
    public function select_portfolio_info_by_id(){
      $sql="SELECT * From tbl_portfolio WHERE portfolio_id=1";
        if (mysqli_query($this->db_connect, $sql)){
        $query_result = mysqli_query($this->db_connect, $sql);
            return $query_result;
        } else {
            die('Query problem' . mysqli_error($this->db_connect));
        }  
    }
    
}