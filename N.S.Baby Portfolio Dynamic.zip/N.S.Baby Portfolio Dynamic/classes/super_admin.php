<?php

class Super_admin {
    private $db_connect;
    public function __construct() {
        $host_name = 'localhost';
        $user_name = 'root';
        $password = '';
        $db_name = 'db_portfolio';
        $this->db_connect = mysqli_connect($host_name, $user_name, $password, $db_name);
        if (!$this->db_connect) {
            die('Connection Fail' . mysqli_error($this->db_connect));
        }
    }

    
    
    
    
    
    public function save_vision_info($data){
        $sql="INSERT INTO tbl_vision (vision_first, vision_image, vision_last) VALUES('$data[vision_first]', '$data[vision_image]', '$data[vision_last]')";
    if(mysqli_query($this->db_connect, $sql)){
        $message="Congratulations! Your vision create successfully.";
        return $message;
    } else {
        die('Query problem'. mysqli_error($this->db_connect));
    }
}



public function save_portfolio_info($data){
    $sql="INSERT INTO tbl_portfolio (objective, graduate, hsc, ssc, training, programming_skill, language_skill) VALUES('$data[objective]', '$data[graduate]', '$data[hsc]', '$data[ssc]', '$data[training]', '$data[programming_skill]', '$data[language_skill]')";
    if(mysqli_query($this->db_connect, $sql)){
        $message="Congratulations! Porfolio info create successfully.";
        return $message;
    } else {
        die('Query problem'. mysqli_error($this->db_connect));
    }
}

public function save_about_info($data){
    $sql="INSERT INTO tbl_about (school_life, college_life, university_life) VALUES('$data[school_life]', '$data[college_life]', '$data[university_life]')";
    if(mysqli_query($this->db_connect, $sql)){
        $message="Congratulations! About info create successfully.";
        return $message;
    } else {
        die('Query problem'. mysqli_error($this->db_connect));
    } 
}
    

public function save_contact_info($data){
    $sql="INSERT INTO tbl_contact (your_name, email_phone, your_message) VALUES('$data[your_name]', '$data[email_phone]', '$data[your_message]')";
    if(mysqli_query($this->db_connect, $sql)){
        $message="Congratulations! Your message sent successfully.";
        return $message;
    } else {
        die('Query problem'. mysqli_error($this->db_connect));
    }
}


















public function logout() {
        unset($_SESSION['admin_name']);
        unset($_SESSION['admin_id']);
        header('Location: index.php');
    }
}
