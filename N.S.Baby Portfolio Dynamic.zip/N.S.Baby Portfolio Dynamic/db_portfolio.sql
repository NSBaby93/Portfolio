-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2016 at 02:42 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_portfolio`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_about`
--

CREATE TABLE IF NOT EXISTS `tbl_about` (
`about_id` int(20) NOT NULL,
  `school_life` text NOT NULL,
  `school_image` text NOT NULL,
  `college_image` text NOT NULL,
  `college_life` text NOT NULL,
  `university_life` text NOT NULL,
  `university_image` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_about`
--

INSERT INTO `tbl_about` (`about_id`, `school_life`, `school_image`, `college_image`, `college_life`, `university_life`, `university_image`) VALUES
(1, 'I start my school life at 1998 at Boheratoli Government Primary School. It''s near my house. I''m lucky to say that I end my school life in 2008 from Joydebpur Government Girls High School. It is one of the most famous school for girls in Gazipur District. When I read in this school I was stay in a girls hostel. I got both Primary Scholarshep and Junior Scholarsheep.\r\n    ', '', '', 'I have complete my college life from Gazipur Govt'' Mohila College. It''s also situated at the heart of Gazipur city and only famous college for girls at Gazipur District. That time I also stay at a girls hostel. I have passed my H.S.C. at 2010.', 'I''m studying my B.Sc Honours at Bhawal Badre Alam Govt'' College under National University. It''s situated at Gazipur District. It''s helps thousands of students every year to end there higher srudies. And I also one of them.', ''),
(2, 'Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. <br>', '', '', 'Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. <br>', 'Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. Well. <br>', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
`admin_id` int(3) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `email_address` varchar(250) NOT NULL,
  `password` varchar(35) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `email_address`, `password`) VALUES
(1, 'Seip PHP 28', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE IF NOT EXISTS `tbl_contact` (
`contact_id` int(55) NOT NULL,
  `your_name` text NOT NULL,
  `email_phone` varchar(100) NOT NULL,
  `your_message` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`contact_id`, `your_name`, `email_phone`, `your_message`) VALUES
(1, '', '', ''),
(2, 'Baby', '01733760115', 'Hi! This is Baby. I want to buy your product.<br>'),
(3, 'Megh', '123456', 'I want to buy a bicycle.<br>'),
(4, 'bbbb', '11111', 'asdfg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dream`
--

CREATE TABLE IF NOT EXISTS `tbl_dream` (
`dream_id` int(10) NOT NULL,
  `dream_details` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE IF NOT EXISTS `tbl_gallery` (
`gallery_id` int(50) NOT NULL,
  `gallery_image` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_portfolio`
--

CREATE TABLE IF NOT EXISTS `tbl_portfolio` (
`portfolio_id` int(11) NOT NULL,
  `objective` text NOT NULL,
  `graduate` text NOT NULL,
  `hsc` text NOT NULL,
  `ssc` text NOT NULL,
  `training` text NOT NULL,
  `programming_skill` text NOT NULL,
  `language_skill` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_portfolio`
--

INSERT INTO `tbl_portfolio` (`portfolio_id`, `objective`, `graduate`, `hsc`, `ssc`, `training`, `programming_skill`, `language_skill`) VALUES
(1, 'Intent to work in challenging and competitive environment where strong sense of responsibility and competitive requires. I strongly believe my skills will equip me to work in any place, where dignity of work provides jobs satisfaction and place of work provides potential avenues to secure an executive position. To secure a long tern executive position within a forward looking company in Bangladesh.', 'Bhawal Badre Alam Govt. College, Gazipur <br />Zoology <br />Third Year', 'Gazipur Govt. Mohila College Group: Science <br />G.P.A.: 3.80 out of 5.00<br />Passing Year: 2010', 'Joydebpur Govt. Girls High School <br />Group: Science <br />G.P.A.: 4.31 out of 5.00<br />Passing Year: 2008', 'Web Development from RRF Institute<br />WordPress Theme Development from SoftTech-IT<br />Web Application Development-PHP from BASIS Institute of Technology & Management.', 'Excellent Reading, Writing, Speaking in Bengali.  <br />Good Reading, Writing, Speaking in English.', 'HTML, CSS, Javascript, JQuery, WordPress, PHP');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vision`
--

CREATE TABLE IF NOT EXISTS `tbl_vision` (
`vision_id` int(55) NOT NULL,
  `vision_first` text NOT NULL,
  `vision_image` text NOT NULL,
  `vision_last` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_vision`
--

INSERT INTO `tbl_vision` (`vision_id`, `vision_first`, `vision_image`, `vision_last`) VALUES
(1, 'I''m Nasrin Sultana Baby. Very industrious person. I like to do works and hate idleness. I believe that ''Industry is really the key to success''. I like all kinds of works as it big or small.', '', 'I want to train up my village people in Information Technology. So that they can be self-dependent, know about modern world and contribute the improvement of Bangladesh.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_about`
--
ALTER TABLE `tbl_about`
 ADD PRIMARY KEY (`about_id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
 ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
 ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `tbl_dream`
--
ALTER TABLE `tbl_dream`
 ADD PRIMARY KEY (`dream_id`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
 ADD PRIMARY KEY (`gallery_id`);

--
-- Indexes for table `tbl_portfolio`
--
ALTER TABLE `tbl_portfolio`
 ADD PRIMARY KEY (`portfolio_id`);

--
-- Indexes for table `tbl_vision`
--
ALTER TABLE `tbl_vision`
 ADD PRIMARY KEY (`vision_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_about`
--
ALTER TABLE `tbl_about`
MODIFY `about_id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
MODIFY `admin_id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
MODIFY `contact_id` int(55) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_dream`
--
ALTER TABLE `tbl_dream`
MODIFY `dream_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
MODIFY `gallery_id` int(50) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_portfolio`
--
ALTER TABLE `tbl_portfolio`
MODIFY `portfolio_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_vision`
--
ALTER TABLE `tbl_vision`
MODIFY `vision_id` int(55) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
