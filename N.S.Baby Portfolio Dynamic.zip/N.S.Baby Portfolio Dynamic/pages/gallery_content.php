<div class="image_gallery"> 
    <img class="img_1" src="assets/front_end_assets/images/img_1.jpg" alt="imgae_1" />
    <img class="img_2" src="assets/front_end_assets/images/img_2.jpg" alt="imgae_2" />
    <img class="img_3" src="assets/front_end_assets/images/img_3.jpg" alt="imgae_3" />
    <img class="img_4" src="assets/front_end_assets/images/img_4.jpg" alt="imgae_4" />
    <img class="img_5" src="assets/front_end_assets/images/img_5.jpg" alt="imgae_5" />
    <img class="img_6" src="assets/front_end_assets/images/img_6.jpg" alt="imgae_6" />
    <img class="img_7" src="assets/front_end_assets/images/img_7.jpg" alt="imgae_7" />
    <img class="img_8" src="assets/front_end_assets/images/img_8.jpg" alt="imgae_8" />
    <img class="img_9" src="assets/front_end_assets/images/img_9.jpg" alt="imgae_9" />
    <img class="img_10" src="assets/front_end_assets/images/img_10.jpg" alt="imgae_10" />
</div>