<?php
include './classes/application.php';
$obj_app= new Application();
$query_result = $obj_app->select_portfolio_info_by_id();
$about_info = mysqli_fetch_assoc($query_result);
?>

<div class="portfolio_area">
    <h2>Career Objective</h2>
    <p><?php echo $about_info['objective']; ?></p>
<!--    <p>Intent to work in challenging and competitive environment where strong sense of responsibility and competitive requires. I strongly believe my skills will equip me to work in any place, where dignity of work provides jobs satisfaction and place of work provides potential avenues to secure an executive position. To secure a long tern executive position within a forward looking company in Bangladesh.</p>-->
    <h2>Educational Information</h2>
    <h2>Bachelor of Science(B.Sc) Honours</h2>
    <p><?php echo $about_info['graduate']; ?></p>
<!--    <p>Bhawal Badre Alam Govt. College, Gazipur <br />Zoology <br />Third Year</p>-->

    <h2>Diploma in Computer Science and Application (D.C.S.A.)</h2>
    <p>Bangladesh Open University <br />Study Center: Dhaka University of Engineering and Technology, Gazipur <br /> Computer Science<br />C.G.P.A. 3.58 out of 4.00</p>

    <h2>Higher Secondary School Certificate (H.S.C.)</h2>
    <p><?php echo $about_info['hsc']; ?></p>
<!--    <p>Gazipur Govt. Mohila College Group: Science <br />G.P.A.: 3.80 out of 5.00<br />Passing Year: 2010</p>-->

    <h2>Secondary School Certificate (S.S.C.)</h2>
    <p><?php echo $about_info['ssc']; ?></p>
<!--    <p>Joydebpur Govt. Girls High School <br />Group: Science <br />G.P.A.: 4.31 out of 5.00<br />Passing Year: 2008</p>-->


    <h2>Training</h2>
    <p><?php echo $about_info['training']; ?></p>
<!--    <p>Web Development from RRF Institute<br />WordPress Theme Development from SoftTech-IT<br />Web Application Development-PHP from BASIS Institute of Technology & Management.</p>-->

    <h2>Language Skills</h2>
    <p><?php echo $about_info['programming_skill']; ?></p>
<!--    <p>Excellent Reading, Writing, Speaking in Bengali.  <br />Good Reading, Writing, Speaking in English.</p>-->

    <h2>Programming Skills</h2>
    <p><?php echo $about_info['language_skill']; ?></p>
<!--    <p>HTML, CSS, Javascript, JQuery, WordPress, PHP</p>-->

</div>