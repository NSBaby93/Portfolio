<?php
//    if(isset($_POST['btn'])){
//    $message = $ob_sup_admin->save_contact_info($_POST);
//}
?>
<h2 style="color: green;"><?php if(isset($message)) {echo $message;} ?></h2>

<div class="contact_area">
    <form action="contact.php" method="post">
        <table>
            <tr>
                <td>Your Name</td>
                <td><input type="text" name="your_name" placeholder="Enter Your Name"/></td>
            </tr>
            <tr>
                <td>Email or Phone Number</td>
                <td><input type="text" name="email_phone" placeholder="Enter your email or phone"/></td>
            </tr>
            <tr>
                <td>Your Message</td>
                <td><textarea name="your_message" id="msg" cols="30" rows="6"></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="btn" value="SUBMIT"/></td>
            </tr>
        </table>
    </form>
</div>