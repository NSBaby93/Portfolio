<?php
include './classes/application.php';
$obj_app= new Application();
$query_result = $obj_app->select_vision_info_by_id();
$about_info = mysqli_fetch_assoc($query_result);
?>

<div class="content_area">
    <div class="vision_area">
        <a href="#"><h2>Vision</h2></a>
        <p><?php echo $about_info['vision_first']; ?></p>
<!--        <p>I'm Nasrin Sultana Baby. Very industrious person. I like to do works and hate idleness. I believe that 'Industry is really the key to success'. I like all kinds of works as it big or small.</p>-->
        <img src="assets/front_end_assets/images/vision_img.jpg" alt="Vision Photo" />
        <p><?php echo $about_info['vision_last']; ?></p>
<!--        <p>I want to train up my village people in Information Technology. So that they can be self-dependent, know about modern world and contribute the improvement of Bangladesh.</p>-->
    </div>
    <div class="dreams_area"> 
        <a href="#"><h2>Dreams</h2></a>
        <ul>
            <li><i class="fa fa-arrow-right"></i>To be a good man</li>
            <li><i class="fa fa-arrow-right"></i>Be a good web developer</li>
            <li><i class="fa fa-arrow-right"></i>Read more and more books</li>
            <li><i class="fa fa-arrow-right"></i>See whole Bangladesh</li>
            <li><i class="fa fa-arrow-right"></i>Help the helpless people</li>
            <li><i class="fa fa-arrow-right"></i>Work at Google or Facebook</li>
            <li><i class="fa fa-arrow-right"></i>Work with Mother Teresa</li>
            <li><i class="fa fa-arrow-right"></i>Create a Cancer Hospital with my group</li>
            <li><i class="fa fa-arrow-right"></i>Create a library in my village</li>
            <li><i class="fa fa-arrow-right"></i>Cycling</li>
        </ul>
    </div>
</div>