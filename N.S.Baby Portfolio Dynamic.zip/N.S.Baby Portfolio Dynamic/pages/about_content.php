<?php
include './classes/application.php';
$obj_app= new Application();
$query_result = $obj_app->select_about_info_by_id();
$about_info = mysqli_fetch_assoc($query_result);
?>

<div class="about_area"> 
    <div class="school_area">
        <div class="article_area"> 
            <a href="#"><h2>School Life</h2></a>
            <p><?php echo $about_info['school_life']; ?></p>
<!--            <p>I start my school life at 1998 at Boheratoli Government Primary School. It's near my house. I'm lucky to say that I end my school life in 2008 from Joydebpur Government Girls High School. It is one of the most famous school for girls in Gazipur District. When I read in this school I was stay in a girls hostel. I got both Primary Scholarshep and Junior Scholarsheep.</p>-->
        </div>
        <div class="image_area">
            <img src="assets/front_end_assets/images/school_img.jpg" alt="School_Image" />
        </div>
    </div>
    <div class="college_area">
        <div class="image_area">
            <img src="assets/front_end_assets/images/college_img.jpg" alt="School_Image" />
        </div>
        <div class="article_area"> 
            <a href="#"><h2>College Life</h2></a>
            <p><?php echo $about_info['college_life']; ?></p>
<!--            <p>I have complete my college life from Gazipur Govt' Mohila College. It's also situated at the heart of Gazipur city and only famous college for girls at Gazipur District. That time I also stay at a girls hostel. I have passed my H.S.C. at 2010.</p>-->
        </div>
    </div>
    <div class="university_area">
        <div class="article_area"> 
            <a href="#"><h2>University Life</h2></a>
            <p><?php echo $about_info['university_life']; ?></p>
<!--            <p>I'm studying my B.Sc Honours at Bhawal Badre Alam Govt' College under National University. It's situated at Gazipur District. It's helps thousands of students every year to end there higher srudies. And I also one of them.</p>-->
        </div>
        <div class="image_area">
            <img src="assets/front_end_assets/images/university_img.jpg" alt="School_Image" />
        </div>
    </div>
</div>	